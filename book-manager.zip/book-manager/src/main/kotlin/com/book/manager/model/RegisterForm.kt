package com.book.manager.model

data class RegisterForm(
    var bookFormList: List<BookForm>,
    var authorFormList: List<AuthorForm>
)
