package com.book.manager.model

data class BookListResponse(
    var bookList: List<BookResponse>
)
