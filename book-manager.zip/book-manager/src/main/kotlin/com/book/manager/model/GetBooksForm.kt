package com.book.manager.model

data class GetBooksForm(
    var authorId: String
)
